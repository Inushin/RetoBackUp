#!/bin/bash

 # Ubicación de almacenamiento temporal de los datos de la copia de seguridad, que se eliminará automáticamente una vez completada la copia de seguridad.			
BACKDIR="/home/ec2-user/RetoBackUp/"
 # Obtener hora del sistema
DATE=`date +%Y%m%d-%H:%M:%S`
 # El nombre del archivo de respaldo se nombra después de tiempo
FILENAME=reto_${DATE}

 #Introduzca el directorio de respaldo
cd ${BACKDIR}

git fetch

 #Backup base de datos y agregar registro
zip -r -s 50m ${BACKDIR}/${FILENAME}.zip /home/ec2-user/docker

 # Eliminar archivos en los últimos 7 días
find ${BACKDIR} -mtime +3 -name "*.zip" -exec rm -rf {} \;

cat >> README.md << EOF
- BackUp realizada el ${DATE}

EOF

git add --all

git commit -m "BackUp_"${DATE}""

git push origin main
